# Creature — The Orrery (`orrery`)

Area: **lunar**. No picture of it among the 150 files. 

## Reference
```
Dark hand-painted 2D game art for a side-scrolling action-exploration game: moody, slightly desaturated palette with one glowing accent colour, clean thin dark ink outline of even weight, soft painted shading from a single light source at the top-left, rim light on the edge facing the light, readable silhouette at small size. Side view, the character faces RIGHT. Original design, not a copy of any existing game or character.
Character reference of the creature "The Orrery": A brass core with one eye, two rings and three orbs circling it. The orbs wound whoever touches them; strike the core between their orbits. Side view facing right (largest), front view, back view. Plain flat mid-grey background, no text, no labels, no swatches, no scenery.
```

## idle — 6 frames
```
Dark hand-painted 2D game art for a side-scrolling action-exploration game: moody, slightly desaturated palette with one glowing accent colour, clean thin dark ink outline of even weight, soft painted shading from a single light source at the top-left, rim light on the edge facing the light, readable silhouette at small size. Side view, the character faces RIGHT. Original design, not a copy of any existing game or character.
Sprite strip of the creature "The Orrery": A brass core with one eye, two rings and three orbs circling it. The orbs wound whoever touches them; strike the core between their orbits.
Animation "idle", 6 frames: idle breathing loop.
THIS IS A RAW SPRITE STRIP, NOT A PRESENTATION BOARD: no title, no logo, no captions, no frame numbers, no labels, no panels, no borders, no UI, no colour swatches, no scenery, no moon, no floor, no cast shadow. One single plain flat mid-grey background (#808080), perfectly even, edge to edge. Only the frames listed, in one horizontal row, left to right in play order, evenly spaced with wide empty grey gaps, never touching. Every frame the same scale and on the same ground line; same design, colours and proportions in every frame. Each frame at least 220 pixels tall; use the widest canvas available (3:1 or 4:1).
```

## walk — 6 frames
```
Dark hand-painted 2D game art for a side-scrolling action-exploration game: moody, slightly desaturated palette with one glowing accent colour, clean thin dark ink outline of even weight, soft painted shading from a single light source at the top-left, rim light on the edge facing the light, readable silhouette at small size. Side view, the character faces RIGHT. Original design, not a copy of any existing game or character.
Sprite strip of the creature "The Orrery": A brass core with one eye, two rings and three orbs circling it. The orbs wound whoever touches them; strike the core between their orbits.
Animation "walk", 6 frames: walk / move cycle.
THIS IS A RAW SPRITE STRIP, NOT A PRESENTATION BOARD: no title, no logo, no captions, no frame numbers, no labels, no panels, no borders, no UI, no colour swatches, no scenery, no moon, no floor, no cast shadow. One single plain flat mid-grey background (#808080), perfectly even, edge to edge. Only the frames listed, in one horizontal row, left to right in play order, evenly spaced with wide empty grey gaps, never touching. Every frame the same scale and on the same ground line; same design, colours and proportions in every frame. Each frame at least 220 pixels tall; use the widest canvas available (3:1 or 4:1).
```

## atk — 6 frames
```
Dark hand-painted 2D game art for a side-scrolling action-exploration game: moody, slightly desaturated palette with one glowing accent colour, clean thin dark ink outline of even weight, soft painted shading from a single light source at the top-left, rim light on the edge facing the light, readable silhouette at small size. Side view, the character faces RIGHT. Original design, not a copy of any existing game or character.
Sprite strip of the creature "The Orrery": A brass core with one eye, two rings and three orbs circling it. The orbs wound whoever touches them; strike the core between their orbits.
Animation "atk", 6 frames: attack: anticipation, strike, recovery.
THIS IS A RAW SPRITE STRIP, NOT A PRESENTATION BOARD: no title, no logo, no captions, no frame numbers, no labels, no panels, no borders, no UI, no colour swatches, no scenery, no moon, no floor, no cast shadow. One single plain flat mid-grey background (#808080), perfectly even, edge to edge. Only the frames listed, in one horizontal row, left to right in play order, evenly spaced with wide empty grey gaps, never touching. Every frame the same scale and on the same ground line; same design, colours and proportions in every frame. Each frame at least 220 pixels tall; use the widest canvas available (3:1 or 4:1).
```

## hurt — 4 frames
```
Dark hand-painted 2D game art for a side-scrolling action-exploration game: moody, slightly desaturated palette with one glowing accent colour, clean thin dark ink outline of even weight, soft painted shading from a single light source at the top-left, rim light on the edge facing the light, readable silhouette at small size. Side view, the character faces RIGHT. Original design, not a copy of any existing game or character.
Sprite strip of the creature "The Orrery": A brass core with one eye, two rings and three orbs circling it. The orbs wound whoever touches them; strike the core between their orbits.
Animation "hurt", 4 frames: hurt flinch.
THIS IS A RAW SPRITE STRIP, NOT A PRESENTATION BOARD: no title, no logo, no captions, no frame numbers, no labels, no panels, no borders, no UI, no colour swatches, no scenery, no moon, no floor, no cast shadow. One single plain flat mid-grey background (#808080), perfectly even, edge to edge. Only the frames listed, in one horizontal row, left to right in play order, evenly spaced with wide empty grey gaps, never touching. Every frame the same scale and on the same ground line; same design, colours and proportions in every frame. Each frame at least 220 pixels tall; use the widest canvas available (3:1 or 4:1).
```

## death — 6 frames
```
Dark hand-painted 2D game art for a side-scrolling action-exploration game: moody, slightly desaturated palette with one glowing accent colour, clean thin dark ink outline of even weight, soft painted shading from a single light source at the top-left, rim light on the edge facing the light, readable silhouette at small size. Side view, the character faces RIGHT. Original design, not a copy of any existing game or character.
Sprite strip of the creature "The Orrery": A brass core with one eye, two rings and three orbs circling it. The orbs wound whoever touches them; strike the core between their orbits.
Animation "death", 6 frames: death: collapse and break-up, last frame a still remains.
THIS IS A RAW SPRITE STRIP, NOT A PRESENTATION BOARD: no title, no logo, no captions, no frame numbers, no labels, no panels, no borders, no UI, no colour swatches, no scenery, no moon, no floor, no cast shadow. One single plain flat mid-grey background (#808080), perfectly even, edge to edge. Only the frames listed, in one horizontal row, left to right in play order, evenly spaced with wide empty grey gaps, never touching. Every frame the same scale and on the same ground line; same design, colours and proportions in every frame. Each frame at least 220 pixels tall; use the widest canvas available (3:1 or 4:1).
```

