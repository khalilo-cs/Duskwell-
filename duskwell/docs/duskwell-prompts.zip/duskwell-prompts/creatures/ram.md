# Creature — Ram (`ram`)

Area: **crossroads**.

Today: idle 1, walk 4, atk 4, dazed 1, hurt 1, death 4.

Design and behaviour: A shaggy beast with ridged horns. It paws the ground, then charges in a line; it is dazed when it hits a wall.


## Prompt 1 — model sheet
```
Dark hand-painted 2D game art for a side-scrolling action-exploration game: moody, slightly desaturated palette with one glowing accent colour, clean thin dark ink outline of even weight, soft painted shading from a single light source at the top-left, rim light on the edge facing the light, readable silhouette at small size. Side view, character faces RIGHT. Original design, not a copy of any existing game or character.
Creature model sheet of "Ram": A shaggy beast with ridged horns. It paws the ground, then charges in a line; it is dazed when it hits a wall. Side view facing right (largest), front view, a close-up of the face and of any weapon or special feature, and 5 colour swatches.
One image. A plain flat mid-grey background (#808080), perfectly even: no gradient, no floor, no cast shadow, no vignette, no text, no labels, no frame lines, no watermark. Every drawing sits in its own invisible cell of a regular grid with clear empty grey space around it, never touching or overlapping another. All drawings in the sheet are the SAME SCALE (the body never gets bigger or smaller between frames) and share the same ground line: feet / lowest point of the body on the same baseline in each row. Same character, same colours, same proportions in every frame. High resolution (at least 2048 px wide).
```

## Prompt 2 — animation sheet (the counts the game uses; you may draw up to double the frames for smoother motion)
```
Dark hand-painted 2D game art for a side-scrolling action-exploration game: moody, slightly desaturated palette with one glowing accent colour, clean thin dark ink outline of even weight, soft painted shading from a single light source at the top-left, rim light on the edge facing the light, readable silhouette at small size. Side view, character faces RIGHT. Original design, not a copy of any existing game or character.
Animation sheet of the creature "Ram" (A shaggy beast with ridged horns. It paws the ground, then charges in a line; it is dazed when it hits a wall.)
Row 1 "idle", 1 frames: idle breathing loop.
Row 2 "walk", 4 frames: walk / move cycle.
Row 3 "atk", 4 frames: attack: anticipation, strike, recovery.
Row 4 "dazed", 1 frames: dazed after hitting a wall, stars or wobble.
Row 5 "hurt", 1 frames: hurt flinch.
Row 6 "death", 4 frames: death: collapse and break-up, last frame a still remains.
Attack row: show a readable anticipation pose (the player must be able to tell the attack is coming), a hard impact pose, then recovery.
One image. A plain flat mid-grey background (#808080), perfectly even: no gradient, no floor, no cast shadow, no vignette, no text, no labels, no frame lines, no watermark. Every drawing sits in its own invisible cell of a regular grid with clear empty grey space around it, never touching or overlapping another. All drawings in the sheet are the SAME SCALE (the body never gets bigger or smaller between frames) and share the same ground line: feet / lowest point of the body on the same baseline in each row. Same character, same colours, same proportions in every frame. High resolution (at least 2048 px wide).
```

## Prompt 3 — extra life (optional)
```
Dark hand-painted 2D game art for a side-scrolling action-exploration game: moody, slightly desaturated palette with one glowing accent colour, clean thin dark ink outline of even weight, soft painted shading from a single light source at the top-left, rim light on the edge facing the light, readable silhouette at small size. Side view, character faces RIGHT. Original design, not a copy of any existing game or character.
Extra animation rows for "Ram": idle variant (blink / sniff / twitch, 6 frames), spotting the player (alert pose, 4 frames), turn-around (4 frames), landing or stop (3 frames), a signature hurt-recoil when hit hard (4 frames), a small effect row for its attack (glow, spit, dust, spark; 6 frames).
One image. A plain flat mid-grey background (#808080), perfectly even: no gradient, no floor, no cast shadow, no vignette, no text, no labels, no frame lines, no watermark. Every drawing sits in its own invisible cell of a regular grid with clear empty grey space around it, never touching or overlapping another. All drawings in the sheet are the SAME SCALE (the body never gets bigger or smaller between frames) and share the same ground line: feet / lowest point of the body on the same baseline in each row. Same character, same colours, same proportions in every frame. High resolution (at least 2048 px wide).
```
