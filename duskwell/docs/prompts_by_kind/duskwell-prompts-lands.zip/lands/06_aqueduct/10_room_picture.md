# Sunken Aqueduct — room picture

```
Dark hand-painted 2D game art for a side-scrolling action-exploration game: moody, slightly desaturated palette with one glowing accent colour, clean thin dark ink outline of even weight, soft painted shading from a single light source at the top-left, rim light on the edge facing the light, readable silhouette at small size. Side view, the character faces RIGHT. Original design, not a copy of any existing game or character.
Area "Sunken Aqueduct": a flooded stone aqueduct: arches, channels, dripping water, algae, rusty grates. Palette: teal-blue stone, cyan water glow.
One finished painting of a typical room of this area seen from the side, as a mood reference (this one image MAY have a full background, still no text).
No text, no labels.
```
