# Mirror Vault — background far

```
Dark hand-painted 2D game art for a side-scrolling action-exploration game: moody, slightly desaturated palette with one glowing accent colour, clean thin dark ink outline of even weight, soft painted shading from a single light source at the top-left, rim light on the edge facing the light, readable silhouette at small size. Side view, the character faces RIGHT. Original design, not a copy of any existing game or character.
Area "Mirror Vault": a sealed vault of black glass and silver frames that reflect everything, polished floors. Palette: black and silver-lilac, white sheen.
A seamless wide background layer, the farthest one: distant silhouettes of the area, very dark and low contrast, wide format 4:1, tiles left to right seamlessly. No characters.
NOT A PRESENTATION BOARD: no title, no logo, no captions, no numbers, no labels, no panels, no swatches. One plain flat mid-grey background (#808080), every piece separate with wide empty grey gaps, side view, lit from the top-left, same scale for all pieces (the hero is 2 tiles tall).
```
