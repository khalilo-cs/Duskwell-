# Lunar Observatory — props standing

```
Dark hand-painted 2D game art for a side-scrolling action-exploration game: moody, slightly desaturated palette with one glowing accent colour, clean thin dark ink outline of even weight, soft painted shading from a single light source at the top-left, rim light on the edge facing the light, readable silhouette at small size. Side view, the character faces RIGHT. Original design, not a copy of any existing game or character.
Area "Lunar Observatory": a moonlit observatory: brass telescopes, star charts, domes, low-gravity floating stones. Palette: deep blue and brass, silver moonlight.
12 standing decorations that sit on the ground (rocks, plants, statues, lamps, crates, bones or crystals as fits the area), each a different size, from knee-high to twice the hero's height.
NOT A PRESENTATION BOARD: no title, no logo, no captions, no numbers, no labels, no panels, no swatches. One plain flat mid-grey background (#808080), every piece separate with wide empty grey gaps, side view, lit from the top-left, same scale for all pieces (the hero is 2 tiles tall).
```
